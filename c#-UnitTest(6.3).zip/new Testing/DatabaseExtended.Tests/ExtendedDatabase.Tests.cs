
using NUnit.Framework;
using System;

namespace Tests
{
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase.ExtendedDatabase dataBaseExtended;
        [SetUp]
        public void Setup()
        {
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase();
        }

        [Test]
        public void ctor_CreateValidArray()
        {
           
            
            var person = new ExtendedDatabase.Person(1, "name1");
            var person1 = new ExtendedDatabase.Person(2, "name2");
            var person2 = new ExtendedDatabase.Person(3, "name3");
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(person, person1, person2);
            Assert.AreEqual(3, dataBaseExtended.Count);
        }
        [Test]
        public void ctor_ThrowExceptionWhenValidMorePeople()
        {
            ExtendedDatabase.Person[] persons = new ExtendedDatabase.Person[17];
            for (int i = 0; i <= 16; i++)
            {
                var person = new ExtendedDatabase.Person(i, "name" + i);
                persons[i] = person;
               
            }
            Assert.Throws<ArgumentException>(() => dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(persons));
        }
         [Test]
         public void Add_ThrowsExceptonArrayCapacity()
        {
            ExtendedDatabase.Person[] persons = new ExtendedDatabase.Person[17];
            for (int i = 0; i <= 15; i++)
            {
                var person = new ExtendedDatabase.Person(i, "name" + i);
                dataBaseExtended.Add(person);

            }
            var finalPerson = new ExtendedDatabase.Person(16, "name16");
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.Add(finalPerson));
        }
        [Test]
        public void Add_ThrowsAlreadyHaveUserWithThisUsername()
        {
            var person = new ExtendedDatabase.Person(1, "name");
            var person1 = new ExtendedDatabase.Person(2, "name");
            dataBaseExtended.Add(person); 
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.Add(person1));
        }
        [Test]
        public void Add_ThrowsAlreadyHaveUserWithThisID()
        {
            var person = new ExtendedDatabase.Person(1, "name");
            var person1 = new ExtendedDatabase.Person(1, "name1");
            dataBaseExtended.Add(person);
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.Add(person1));
        }

        [Test]
        public void Add_ValidPerson()
        {
            var person = new ExtendedDatabase.Person(1, "name");
            var person1 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended.Add(person);
            dataBaseExtended.Add(person1);
            Assert.AreEqual(2, dataBaseExtended.Count);
        }
        [Test]
        public void Remove_ThrowsWhenRemoveFromColectionWithZeroElement()
        {
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.Remove());
        }
        [Test]
        public void Remove_ValidCount()
        {
            var person = new ExtendedDatabase.Person(1, "name");
            var person1 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended.Add(person);
            dataBaseExtended.Add(person1);
            dataBaseExtended.Remove();
            Assert.AreEqual(1, dataBaseExtended.Count);
        }

        [TestCase("")]
        [TestCase(null)]
        public void FindByUsername_ThrowsWhenUsernameParameterIsNull(string name)
        {
           
            Assert.Throws<ArgumentNullException>(() => dataBaseExtended.FindByUsername(name));
        }

        [TestCase("pavel")]
        [TestCase("ivan")]
        public void FindByUsername_ThrowsNoUserPresentByThisUsername(string name)
        {
            var person1 = new ExtendedDatabase.Person(1, "name");
            var person2 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(person1, person2);
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.FindByUsername(name));
        }

        [Test]
        public void FindByUsername_ValidPersonName()
        {
           
            var person1 = new ExtendedDatabase.Person(1,"name");
            var person2 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(person1, person2);

            Assert.AreEqual(person1, dataBaseExtended.FindByUsername("name"));

        }
        [Test]
        public void FindById_ThrowExceptionWhenIdIsEqualToZero()
        {
           
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.FindById(1));
        }
        [Test]
        public void FindById_ThrowExceptionNoFindUserByThisID()
        {

            var person1 = new ExtendedDatabase.Person(1, "name");
            var person2 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(person1, person2);
            Assert.Throws<InvalidOperationException>(() => dataBaseExtended.FindById(3));
        }
        [Test]
        public void FindByUsername_ValidPersonByID()
        {

            var person1 = new ExtendedDatabase.Person(1, "name");
            var person2 = new ExtendedDatabase.Person(2, "name1");
            dataBaseExtended = new ExtendedDatabase.ExtendedDatabase(person1, person2);

            Assert.AreEqual(person1, dataBaseExtended.FindById(1));

        }
    }
}