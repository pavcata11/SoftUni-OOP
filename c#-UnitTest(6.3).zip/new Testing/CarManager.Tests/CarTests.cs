
using NUnit.Framework;
using System;
using System.Runtime.ConstrainedExecution;
using CarManager;
namespace Tests
{
    public class CarTests
    {
        private Car car;
        [SetUp]
       
        public void Setup()
        {
            car = new Car("pavel","Golf",7,50);
            
        }

        [TestCase("", "Golf", 5, 50)]
        [TestCase(null, "Golf", 5, 50)]
        [TestCase("pavel", "", 5, 50)]
        [TestCase("ivan", null, 5, 50)]
        [TestCase("krasi", "Golf", 0, 50)]
        [TestCase("gosho", "Golf", -1, 50)]
        [TestCase("petar", "Golf", 5, -50)]
      
        public void Ctro_ThrowsExceptionWhenCreatingCar(string make,string model, double fuelConsumption, double fuelCapacity)
        {
            Assert.Throws<ArgumentException>(()=>car = new Car(make,model,fuelConsumption,fuelCapacity));
        }
        [Test]
        public void Ctro_ThrowsExceptionFuelAmount()
        {
            Assert.AreEqual(0, this.car.FuelAmount);
        }
        [TestCase(0)]
        [TestCase(-20)]
        public void Refuel_RefuelExceptionAmountnotBeZeroOrLess(double refuel)
        {
            Assert.Throws<ArgumentException>(() => car.Refuel(refuel));
        }
        [TestCase(5)]
        public void Refuel_IncreaseFuelAmount(double refuel)
        {
            var amount = car.FuelAmount;
            car.Refuel(refuel);
            Assert.AreEqual(car.FuelAmount, amount + refuel);
        }
        [Test]
        public void Refuel_FuelAmountMoreThenFuelCapacity()
        {


            this.car.Refuel(350);
            int expectedFuel = 50;

            Assert.AreEqual(expectedFuel, this.car.FuelAmount);
        }
        [TestCase(1000)]
        public void Drive_ThrowExceptionNoEnaughFuel(double distance)
        {

            Assert.Throws<InvalidOperationException>(()=>car.Drive(distance)) ;
        }

        [Test]
        public void Drive_IsValiDistance ()
        {
            car.Refuel(10);
            car.Drive(100);
            int expectedFuel = 3;
            Assert.AreEqual(expectedFuel, this.car.FuelAmount);
        }


    }
}