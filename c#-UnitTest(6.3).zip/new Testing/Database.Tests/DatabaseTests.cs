using NUnit.Framework;
using System;

namespace Tests
{
    public class DatabaseTests
    {
        private Database.Database database;
        [SetUp]
        public void Setup()
        {
            database = new Database.Database();
        }

        [Test]
        public void ctor_CheckLenghtCreateArray()
        {
           database = new Database.Database(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16);
            Assert.That(16, Is.EqualTo(database.Count));
        }
        [Test]
        public void ctor_validElementInputingArray()
        {
            database.Add(1);
            database.Add(2);
            Assert.That(2, Is.EqualTo(database.Count));
        }
        [Test]
        public void Add_ThrowExecptionIfElementMore()
        {
           database = new Database.Database(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16);
            Assert.Throws<InvalidOperationException>(() => database.Add(17));
        }
        [Test]
        public void Remove_ThrowExceptionWhenArrayHaveZeroElement()
        {
           
            Assert.Throws<InvalidOperationException>(() => database.Remove());
        }
        [Test]
        public void Remove_ValidRemoveElementFromArray()
        {
            database.Add(1);
            database.Add(2);
            database.Remove();
            Assert.AreEqual(1, database.Count);
        }
        [Test]
        public void Fetch_Valid()
        {
            database.Add(1);
            database.Add(2);
            var data = database.Fetch();
            Assert.AreEqual(data, new int[2] { 1, 2 });
        }


    }
}