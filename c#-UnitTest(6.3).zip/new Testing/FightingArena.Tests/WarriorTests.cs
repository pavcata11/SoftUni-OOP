using NUnit.Framework;
using System;

namespace Tests
{
    public class WarriorTests
    {
        private Warrior warrior;
        [SetUp]
        public void Setup()
        {
            warrior = new Warrior("pavel", 80, 20);
        }

        [TestCase("", 10, 10)]
        [TestCase(null, 10, 10)]
        [TestCase("pavel", 0, 10)]
        [TestCase("plamen", -123, 10)]
        [TestCase("something", 90, -10)]
        public void Ctor_ThrowsExceptionWhenValidIncorectInput(string name,int damage,int hp)
        {
            Assert.Throws<ArgumentException>(()=> warrior = new Warrior(name,damage,hp));
        }

        [TestCase("something", 90, 10)]
        public void Ctor_IsSetCorectly(string name, int damage, int hp)
        {
            warrior = new Warrior(name, damage, hp);
            Assert.AreEqual(warrior.Name, "something");
            Assert.AreEqual(warrior.Damage, 90);
            Assert.AreEqual(warrior.HP, 10);
        }

       [Test]
        public void Atack_WhenWarriorHPIstoLow()
        {
            warrior = new Warrior("pavel", 80, 20);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(new Warrior("something",30,30)));
       
        }
        [Test]
        public void Atack_WhenWarriorAtackerHPIstoLow()
        {
            warrior = new Warrior("pavel", 80, 40);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(new Warrior("something", 30, 20)));

        }
        [Test]
        public void Atack_WhenWariorDamageIsLessThanAtackerDamage()
        {
            warrior = new Warrior("pavel", 80, 40);
            Assert.Throws<InvalidOperationException>(() => warrior.Attack(new Warrior("something", 60, 40)));

        }
        [Test]
        public void Atack_ValidCalculateHP()
        {
            warrior = new Warrior("pavel", 80, 80);
            warrior.Attack(new Warrior("something", 60, 40));
            Assert.AreEqual(20, warrior.HP) ;

        }
        [Test]
        public void Atack_DamageIsMoreThanHP()
        {
            warrior = new Warrior("pavel", 180, 180);
            var warAtacker = new Warrior("something", 60, 40);
            warrior.Attack(warAtacker);
            Assert.AreEqual(0, warAtacker.HP);

        }
        [Test]
        public void Atack_CalculateHP()
        {
            warrior = new Warrior("pavel", 30, 180);   
            var warAtacker = new Warrior("something", 60, 40);
            warrior.Attack(warAtacker);
            Assert.AreEqual(10, warAtacker.HP);

        }

    }
}