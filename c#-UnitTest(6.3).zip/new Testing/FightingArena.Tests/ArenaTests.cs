﻿using NUnit.Framework;
using System;
using System.Linq;

namespace Tests
{
    public class ArenaTests
    {
        private Arena arena;
        private Warrior warrior;
        [SetUp]
       
        public void Setup()
        {
            this.arena = new Arena();
           
        }

        [Test]
        public void Ctor_initilise()
        {

            Assert.That(arena.Warriors, Is.Not.Null);
        }
     
        [Test]
        public void Count_ValidationIsSame()
        {
            Assert.That(arena.Count, Is.EqualTo(0));
        }

        [Test]
        public void Enroll_ThrowExceptopnWithSameName()
        {
            var warrior = new Warrior("sfds", 324, 234);
            arena.Enroll(warrior);
            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));
        }
        [Test]
        public void Enroll_ValidAddInColection()
        {
           
            var warrior = new Warrior("sfds", 324, 234);
            arena.Enroll(warrior);
            Assert.That(arena.Warriors.Count, Is.EqualTo(1));
        }
        [Test]
        public void Enroll_AddInColection()
        {
            string name = "name";
            var warrior = new Warrior(name, 324, 234);
            arena.Enroll(warrior);
            Assert.That(arena.Warriors.Any(w => w.Name == name), Is.True);
        }
        [TestCase(null,"name1")]
        [TestCase("name2", null)]
        [TestCase(null, null)]
        public void Fight_Exception(string name1,string name2)
        {
          
            Assert.Throws<InvalidOperationException>(() => arena.Fight(name1, name2));
           
        }
       
        
        [Test]
        public void Fight_NameValidation()
        {
            int initional = 100;
            var warriorAtack = new Warrior("sfds", 50, initional);
            var warriorDefender = new Warrior("sdas", 50, initional);

            arena.Enroll(warriorAtack);
            arena.Enroll(warriorDefender);

            arena.Fight(warriorAtack.Name, warriorDefender.Name);
            Assert.That(warriorAtack.HP, Is.EqualTo(initional - warriorDefender.Damage));
            Assert.That(warriorDefender.HP, Is.EqualTo(initional - warriorAtack.Damage));

        }

    }
}
