using FightingArena;
using NUnit.Framework;
using System;

namespace Tests
{
    public class WarriorTests
    {
        private Warrior warrior;
        [SetUp]
        public void Setup()
        {
            this.warrior = new Warrior("Hector", 88, 100);
        }
        
        [TestCase(null, 50, 30)]
        [TestCase("", 50, 30)]
        [TestCase(" ", 50, 30)]
        [TestCase("Pesho", 0, 30)]
        [TestCase("Ivan", -10, 30)]
        [TestCase("Ivan", 50, -10)]
        public void ctor_WarriorThrowsException(string name, int damage, int hp)
        {
            Assert.Throws<ArgumentException>(()=>warrior=new Warrior(name,damage,hp));
        }

       [Test]
        public void ctor_WarriorValidInput()
        {
            Assert.That(warrior, Is.EqualTo(warrior));
        }
        

        [TestCase("Achilles", 110, 120)]
        [TestCase("Thor", 400, 540)]
        [TestCase("Zeus", 250, 230)]
        public void AttackShouldThrowExceptionWhenTryingToAttackStrongerEnemy(
            string name, int damage, int hp)
        {
            var enemy = new Warrior(name, damage, hp);

            Assert.Throws<InvalidOperationException>(() =>
            {
                this.warrior.Attack(enemy);
            });
        }

        [TestCase(30)]
        [TestCase(16)]
        [TestCase(0)]
        public void AttackShouldThrowExceptionWhenAttackerHpAreLessThanMinimumHp(int hp)
        {
            var attacker = new Warrior("Silver", 90, hp);

            Assert.Throws<InvalidOperationException>(() =>
            {
                attacker.Attack(this.warrior);
            });
        }
        [TestCase(30)]
        [TestCase(13)]
        [TestCase(0)]
        public void AttackShouldThrowExceptionWhenDefenderHpAreLessThanMinimumHp(int hp)
        {
            var defender = new Warrior("Shogun", 45, hp);

            Assert.Throws<InvalidOperationException>(() =>
            {
                this.warrior.Attack(defender);
            });
        }

      [Test]
        public void Atack_ValidDamageMoreThenHp()
        {
            var attacker = new Warrior("Silver", 105, 133);
            attacker.Attack(this.warrior);
            Assert.AreEqual(0,warrior.HP);
        }
        [Test]
        public void Atack_ValidDamageLessThenHp()
        {
            var attacker = new Warrior("Silver", 90, 133);
            attacker.Attack(this.warrior);
            Assert.AreEqual(0, attacker.HP);
        }


    }
    
}