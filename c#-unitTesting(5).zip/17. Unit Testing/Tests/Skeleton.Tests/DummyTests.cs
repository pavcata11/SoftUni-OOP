﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    private Axe axe;
    private Dummy dummy;
    [SetUp]
    public void Initialised()
    {
        axe = new Axe(10, 5);
        dummy = new Dummy(30, 10);

    }
    [Test]
    public void DummyLosesHealthIfAttacked()
    {
        axe.Attack(dummy);
        Assert.That(dummy.Health, Is.EqualTo(20));
    }
    [Test]
    public void DeadDummyThrowsExceptionaAtacked()
    {
        axe.Attack(dummy);
        axe.Attack(dummy);
        axe.Attack(dummy);
        Assert.That(() => axe.Attack(dummy), Throws.InvalidOperationException
            .With.Message.EqualTo("Dummy is dead."));
    }
    [Test]
    public void DeadDummyCanGiveXP()
    {
        axe.Attack(dummy);
        axe.Attack(dummy);
        axe.Attack(dummy);
        Assert.That(dummy.GiveExperience, Is.EqualTo(10));
    }
    [Test]
    public void AliveDummyCanNotGiveXP()
    {
        Assert.That(() => dummy.GiveExperience(), Throws.InvalidOperationException
          .With.Message.EqualTo("Target is not dead."));
    }
}
