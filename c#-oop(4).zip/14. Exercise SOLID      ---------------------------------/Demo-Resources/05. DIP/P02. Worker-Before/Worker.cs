﻿namespace P02._Worker_Before
{
    public class Worker
    {
        public void Work()
        {
            //work
        }
    }
}
