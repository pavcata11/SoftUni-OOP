﻿namespace P01._Worker_Before.Contracts
{
    public interface IWorker
    {
        void Eat();

        void Work();

        void Sleep();
    }
}
