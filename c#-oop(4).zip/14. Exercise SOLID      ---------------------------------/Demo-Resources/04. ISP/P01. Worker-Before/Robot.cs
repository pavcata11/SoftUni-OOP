﻿namespace P01._Worker_Before
{
    using Contracts;

    public class Robot : IWorker
    {
        public void Eat()
        {
            throw new System.NotImplementedException();
        }

        public void Sleep()
        {
            throw new System.NotImplementedException();
        }

        public void Work()
        {
            // work
        }
    }
}
