﻿using CommandPattern.Core.Contracts;

namespace CommandPattern
{
    internal class Engine : IEngine
    {
        private ICommandInterpreter command;

        public Engine(ICommandInterpreter command)
        {
            this.command = command;
        }

        public void Run()
        {
            throw new System.NotImplementedException();
        }
    }
}