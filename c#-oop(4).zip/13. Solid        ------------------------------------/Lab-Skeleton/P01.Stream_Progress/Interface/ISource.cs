﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.Stream_Progress.Interface
{
    interface ISource
    {
        int Length { get; }
    }
}
