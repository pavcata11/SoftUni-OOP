﻿namespace P04.Recharge
{
    using System;

    class Program
    {
        static void Main()
        {
        }
    }
}
