﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string name, params string[] nameOfFields)
        {
            Type classType = Type.GetType(name);
            FieldInfo[] classFields = classType.GetFields(
                BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
            var sb = new StringBuilder();
            object classInstance = Activator.CreateInstance(classType, new object[] { });
            sb.AppendLine($"Class under investigation: {name}");
            foreach (FieldInfo field in classFields.Where(f => nameOfFields.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }
            return sb.ToString().TrimEnd();

        }
        public string AnalyzeAccessModifiers(string className)
        {
            Type classType = Type.GetType(className);
            FieldInfo[] classFields = classType.GetFields(
                BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public);
            MemberInfo[] classPublicMethod = classType.GetFields(BindingFlags.Instance | BindingFlags.Public);
            MemberInfo[] classNotPublicMethod = classType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            var sb = new StringBuilder();
            foreach (var item in classFields)
            {
                sb.AppendLine($"{item.Name} must be private!");

            }
            foreach (var item in classNotPublicMethod.Where(m => m.Name.StartsWith("get")))
            {
                sb.AppendLine($"{item.Name} have to be public!");

            }
            foreach (var item in classPublicMethod.Where(m => m.Name.StartsWith("set")))
            {
                sb.AppendLine($"{item.Name} have to be private!");
            }
            return sb.ToString().TrimEnd();

        }
        public string RevealPrivateMethods(string className)
        {
            Type classType = Type.GetType(className);
            MemberInfo[] methodInfo = classType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);
            var sb = new StringBuilder();
            sb.AppendLine($"All private methods of Class: {className}");
            sb.AppendLine($"Base Class: {classType.BaseType.Name}");
            foreach (var item in methodInfo)
            {
                sb.AppendLine(item.Name);

            }
            return sb.ToString().TrimEnd();
        }
        public string CollectGetterAndSetter(string nameClass)
        {
            Type classType = Type.GetType(nameClass);
            MethodInfo[] classInfo = classType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
            var sb = new StringBuilder();
            foreach (var item in classInfo.Where(f=>f.Name.StartsWith("get")))
            {
                sb.AppendLine($"{item.Name} will return {item.ReturnType}");

            }
            foreach (var item in classInfo.Where(f => f.Name.StartsWith("set")))
            {
                sb.AppendLine($"{item.Name} will set field of {item.GetParameters().First().ParameterType}");

            }
            return sb.ToString().TrimEnd();
        }
    }

}
