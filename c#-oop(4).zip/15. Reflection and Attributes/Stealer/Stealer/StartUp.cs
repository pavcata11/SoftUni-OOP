﻿using System;

namespace Stealer
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();
             //string result = spy.StealFieldInfo("Stealer.Hacker", "username", "password");
            // string result = spy.AnalyzeAccessModifiers("Stealer.Hacker");
            //string result = spy.RevealPrivateMethods("Stealer.Hacker");
            string result = spy.CollectGetterAndSetter("Stealer.Hacker");
            Console.WriteLine(result);
        }
    }
}
