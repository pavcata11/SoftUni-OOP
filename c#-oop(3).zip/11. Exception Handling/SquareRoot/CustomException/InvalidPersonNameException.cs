﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomException
{
    public class InvalidPersonNameException:Exception
    {
        public InvalidPersonNameException() { }

        public InvalidPersonNameException(Person person)
            : base(string.Format("Invalid Student Name First or Last name: {0}", person))
        {
            

          
        }

    }
}
