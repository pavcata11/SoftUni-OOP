﻿using System;

namespace SquareRoot
{
    class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                int number = int.Parse(Console.ReadLine());
                Console.WriteLine(Math.Sqrt(number));
            }
            
            catch (ArithmeticException)
            {

                throw new ArithmeticException();
            }
           
            catch (NullReferenceException)
            {
                throw new NullReferenceException();
            }
            catch(ArgumentException)
            {
                throw new ArgumentException();
            }
            catch(Exception)
            {
                throw new ArgumentException();
            }

            finally
            {
                Console.WriteLine("Good bye");
            }
        }
    }
}
