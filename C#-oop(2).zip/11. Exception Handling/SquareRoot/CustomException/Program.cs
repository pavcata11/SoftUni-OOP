﻿using System;

namespace CustomException
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var pesho = new Person("Pes000ho", "Peshev", 24);
                // var noName = new Person(string.Empty, "Goshev", 31);
                //  var noLastName = new Person("Pavel", null, 23);
                //  var negativeAge = new Person("Ivan", "Ivanov", -56);
                // var toOldForThisProgram = new Person("Daniel", "Ivanov", 157);
                Validation(pesho);
            }
            catch(InvalidPersonNameException pe)
            {
                Console.WriteLine(pe.Message);
            }
            catch (ArgumentNullException ae)
            {

                Console.WriteLine("Exeptiom throw:  {0}", ae.Message);
            }
            catch (ArgumentOutOfRangeException aore)
            {
                Console.WriteLine("Exeptiom throw:  {0}", aore.Message);
            }

        }
        public static void Validation (Person person)
        {
            var symbol = person.FirstName+person.LastName.ToCharArray();
            for (int i = 0; i < symbol.Length; i++)
            {
                if (char.IsDigit(symbol[i]))
                {
                    throw new InvalidPersonNameException(person);
                }
            }
        }
    }
}
