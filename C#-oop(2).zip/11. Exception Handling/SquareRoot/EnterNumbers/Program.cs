﻿using System;

namespace EnterNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadNumber(0, 100);
        }
        public static void ReadNumber(int start, int end)
        {
            for (int i = 0; i <10; i++)
            {
                try
                {
                    int number = int.Parse(Console.ReadLine());
                    if(number>=start && number <= end)
                    {
                        
                    }
                    else
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                }
                catch (ArgumentOutOfRangeException ar)
                {

                    Console.WriteLine(ar.Message);
                    i = 0;
                }
              
                catch(FormatException fe)
                {
                    Console.WriteLine(fe.Message);
                    i = 0;
                }
                
            }
        }
    }
}
