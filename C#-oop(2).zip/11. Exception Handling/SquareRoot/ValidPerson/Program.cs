﻿using System;

namespace ValidPerson
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var pesho = new Person("Pesho","Peshev",24);
              //  var noName = new Person(string.Empty, "Goshev", 31);
              //  var noLastName = new Person("Pavel", null, 23);
              //  var negativeAge = new Person("Ivan", "Ivanov", -56);
               // var toOldForThisProgram = new Person("Daniel", "Ivanov", 157);

            }
            catch (ArgumentNullException ae)
            {

                Console.WriteLine("Exeptiom throw:  {0}",ae.Message);
            }
            catch (ArgumentOutOfRangeException aore)
            {
                Console.WriteLine("Exeptiom throw:  {0}", aore.Message);
            }
           
        }
    }
}
