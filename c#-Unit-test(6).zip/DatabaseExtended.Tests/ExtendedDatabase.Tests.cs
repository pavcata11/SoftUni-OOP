using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Tests
{
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase.ExtendedDatabase dataBase;
        [SetUp]
        public void Setup()
        {
            dataBase = new ExtendedDatabase.ExtendedDatabase();
        }

        [Test]
        public void ThereAreUserWithSameUserName()
        {
            var person = new ExtendedDatabase.Person(1, "pavcata11");
            var person1 = new ExtendedDatabase.Person(2, "pavcata11");
            dataBase.Add(person);

            Assert.That(() => dataBase.Add(person1), Throws.InvalidOperationException
                .With.Message.EqualTo("There is already user with this username!"));
        }
        [Test]
        public void ThereAreUserWithSameId()
        {
            var person = new ExtendedDatabase.Person(1, "pavcata11");
            var person1 = new ExtendedDatabase.Person(1, "pavcata22");
            dataBase.Add(person);
            Assert.That(() => dataBase.Add(person1), Throws.InvalidOperationException
              .With.Message.EqualTo("There is already user with this Id!"));
        }
        [Test]
        public void RemoveFromNullElementFromArray()
        {
            Assert.Throws<InvalidOperationException>(() => dataBase.Remove());
        }
        [Test]
        public void RemoveFromArray()
        {
            var person = new ExtendedDatabase.Person(1, "pavcata11");
            dataBase.Add(person);
            dataBase.Remove();
            Assert.That(dataBase.Count, Is.EqualTo(0));
        }
        [Test]
        public void NoUserIsPresentByThisUsername()
        {
            Assert.That(() => dataBase.FindByUsername("pavcata11"), Throws.InvalidOperationException
             .With.Message.EqualTo("No user is present by this username!"));
        }
        [Test]
        public void UsernameParameterIsNull()
        {
            string name = null;
            Assert.Throws<ArgumentNullException>(() => dataBase.FindByUsername(name));

        }
        [Test]
        public void NoUserByThisId()
        {
            Assert.That(() => dataBase.FindById(1), Throws.InvalidOperationException
          .With.Message.EqualTo("No user is present by this ID!"));
        }
        [Test]
       public void negativeId()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => dataBase.FindById(-1));
        }
        [Test]
        public void AddPerson()
        {
            var person = new ExtendedDatabase.Person(1, "pavcata11");
            dataBase.Add(person);
            Assert.AreEqual(1, dataBase.Count);
        }
        [Test]
        public void CreatePerson()
        {
            List<ExtendedDatabase.Person> persons = new List<ExtendedDatabase.Person>();
            for (int i = 0; i <= 16; i++)
            {
                var person = new ExtendedDatabase.Person(i, "name" + 1);
                persons.Add(person);
            }
            var personFinal = new ExtendedDatabase.Person(99, "pavel");
            persons.Add(personFinal);
            Assert.Throws<ArgumentException>(() => dataBase = new ExtendedDatabase.ExtendedDatabase(persons.ToArray()));
        }
        [Test]
        public void FindById()
        {
            var person = new ExtendedDatabase.Person(1, "pavcata11");
            var person1 = new ExtendedDatabase.Person(2, "pavcata111");
            dataBase.Add(person);
            dataBase.Add(person1);
            Assert.That(dataBase.FindById(1), Is.EqualTo(person));
        }
       
    }
}