﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            //TODO Check cast
            double multyPlayer = 0;
            if(racerOne==null && racerTwo == null)
            {
                throw new ArgumentException(OutputMessages.RaceCannotBeCompleted);
            }
            else if (racerOne == null && racerTwo != null)
            {
                throw new ArgumentException(string.Format(OutputMessages.OneRacerIsNotAvailable, racerTwo, racerOne));
            }
            else  if (racerOne != null && racerTwo == null)
            {
                throw new ArgumentException(string.Format(OutputMessages.OneRacerIsNotAvailable, racerOne, racerTwo));
            }
            else
            {
                racerOne.Race();
                racerTwo.Race();
                if(racerOne.RacingBehavior== "strict")
                {
                    racerOne = racerOne as ProfessionalRacer;
                    multyPlayer = 1.2;
                }
                else
                {
                    racerOne = racerOne as StreetRacer;
                    multyPlayer = 1.1;
                }
                var firstChache = racerOne.Car.HorsePower * racerOne.DrivingExperience * multyPlayer;
                if (racerTwo.RacingBehavior == "strict")
                {
                    racerTwo = racerTwo as ProfessionalRacer;
                    multyPlayer = 1.2;
                }
                else
                {
                    racerTwo = racerTwo as StreetRacer;
                    multyPlayer = 1.1;
                }
                var secondChanche = racerTwo.Car.HorsePower * racerTwo.DrivingExperience * multyPlayer;
                if (firstChache > secondChanche)
                {
                    //firstwin
                    return string.Format(OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerOne.Username);
                }
                return string.Format(OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerTwo.Username);
                //seconwin
            }
        }
    }
}
