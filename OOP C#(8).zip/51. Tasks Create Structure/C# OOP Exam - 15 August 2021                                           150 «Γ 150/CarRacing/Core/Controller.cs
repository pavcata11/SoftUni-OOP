﻿using CarRacing.Core.Contracts;
using CarRacing.Models.Cars;
using CarRacing.Models.Cars.Contracts;
using CarRacing.Models.Maps;
using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Repositories;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarRacing.Core
{
    public class Controller : IController
    {
        
        private CarRepository cars;
        private RacerRepository racers;
        private IMap map;
        public Controller()
        {
            cars = new CarRepository();
            racers = new RacerRepository();
            map = new Map();
        }

        public string AddCar(string type, string make, string model, string VIN, int horsePower)
        {
            if(type!= "SuperCar" && type!= "TunedCar")
            {
                throw new ArgumentException(ExceptionMessages.InvalidCarType);
            }
            ICar car = default;
            if (type == "SuperCar")
            {
                 car = new SuperCar(make, model, VIN, horsePower);
            }
            else
            {
                car = new TunedCar(make, model, VIN, horsePower);
            }
            cars.Add(car);
            return string.Format(OutputMessages.SuccessfullyAddedCar, make, model, VIN);
        }

        public string AddRacer(string type, string username, string carVIN)
        {
            var car = cars.FindBy(carVIN);
            if (car == null)
            {
                throw new ArgumentException(ExceptionMessages.CarCannotBeFound);
            }
            else if (type != "StreetRacer" && type != "ProfessionalRacer")
            {
                throw new ArgumentException(ExceptionMessages.InvalidRacerType);
            }
            Racer racer = default;
            if (type == "StreetRacer")
            {
                racer = new StreetRacer(username, car);
            }
            else
            {
                racer = new ProfessionalRacer(username, car);
            }
            
            racers.Add(racer);
            return string.Format(OutputMessages.SuccessfullyAddedRacer,username);
        }

        public string BeginRace(string racerOneUsername, string racerTwoUsername)
        {
            var firstRacer = racers.FindBy(racerOneUsername);
            var secondRacer = racers.FindBy(racerTwoUsername);
            
            if(firstRacer==null)
            {
                return string.Format(ExceptionMessages.RacerCannotBeFound,racerOneUsername);
            }
            else if(secondRacer==null)
            {
                return string.Format(ExceptionMessages.RacerCannotBeFound, racerTwoUsername);
            }
        
            
            return map.StartRace(firstRacer, secondRacer).ToString();


        }

        public string Report()
        {

            var sb = new StringBuilder();
            foreach (var item in racers.Models.OrderByDescending(e => e.DrivingExperience).ThenBy(u => u.Username))
            {
                sb.AppendLine($"{item.GetType().Name}: {item.Username}");
                sb.AppendLine($"--Driving behavior: {item.RacingBehavior}");
                sb.AppendLine($"--Driving experience: {item.DrivingExperience}");
                sb.AppendLine($"--Car: {item.Car.Make} {item.Car.Model} ({item.Car.VIN})");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
