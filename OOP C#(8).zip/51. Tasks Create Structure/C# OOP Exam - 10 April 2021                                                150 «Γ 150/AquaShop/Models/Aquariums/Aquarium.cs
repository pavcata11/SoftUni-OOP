﻿using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish.Contracts;
using AquaShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Models.Aquariums
{
    public abstract class Aquarium : IAquarium
    {
        private string name;
        private List<IDecoration> decorations;
        private List<IFish> fishs;
        public Aquarium(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            decorations = new List<IDecoration>();
            fishs = new List<IFish>();
        }
        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidAquariumName);
                }
                name = value;
            }
        }

        public int Capacity { get; private set; }

        public int Comfort => decorations.Sum(d => d.Comfort);

        public ICollection<IDecoration> Decorations => decorations;

        public ICollection<IFish> Fish => fishs;

        public void AddDecoration(IDecoration decoration)
        {
            decorations.Add(decoration);
        }

        public void AddFish(IFish fish)
        {
            if (Capacity == fishs.Count)
            {
                throw new ArgumentException(ExceptionMessages.NotEnoughCapacity);
            }
            fishs.Add(fish);
            
        }

        public void Feed()
        {
            foreach (var item in fishs)
            {
                item.Eat();
            }
        }

        public string GetInfo()
        {
            
            var sb = new StringBuilder();
            sb.AppendLine($"{Name} ({typeof(Aquarium)}):");
            sb.AppendLine("Fish: ");
            if (fishs.Count > 0)
            {
                foreach (var item in fishs)
                {
                    sb.Append($"{item.Name}, ");
                }
            }
            else
            {
                sb.Append($"none");
            }
            sb.ToString().TrimEnd();
            sb.AppendLine($"Decorations: {decorations.Count}");
            sb.AppendLine($"Comfort: {this.Comfort}");
            return sb.ToString().TrimEnd();
        }

        public bool RemoveFish(IFish fish)
        {
            return fishs.Remove(fish);
        }
    }
}
