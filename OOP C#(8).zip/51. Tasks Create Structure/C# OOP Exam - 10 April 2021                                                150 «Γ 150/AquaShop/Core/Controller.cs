﻿using AquaShop.Core.Contracts;
using AquaShop.Models.Aquariums;
using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Decorations;
using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish;
using AquaShop.Models.Fish.Contracts;
using AquaShop.Repositories;
using AquaShop.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Core
{
    public class Controller : IController
    {
        private DecorationRepository decorations;
        private List<IAquarium> aquariums;
        public Controller()
        {
            decorations = new DecorationRepository();
            aquariums = new List<IAquarium>();
        }

        public string AddAquarium(string aquariumType, string aquariumName)
        {
            if(aquariumType!=nameof(FreshwaterAquarium) && aquariumType != nameof(SaltwaterAquarium))
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidAquariumType);
            }
            IAquarium aquarium = default;
            if(aquariumType == nameof(FreshwaterAquarium))
            {
                aquarium = new FreshwaterAquarium(aquariumName);
            }
            else
            {
                aquarium = new SaltwaterAquarium(aquariumName);
            }
            aquariums.Add(aquarium);
            return string.Format(OutputMessages.SuccessfullyAdded, aquarium.GetType().Name);
        }

        public string AddDecoration(string decorationType)
        {
            if (decorationType != nameof(Ornament) && decorationType != nameof(Plant))
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidDecorationType);
            }
            IDecoration decoration = default;
            if (decorationType == nameof(Ornament))
            {
                decoration = new Ornament();
            }
            else
            {
                decoration = new Plant();
            }
            decorations.Add(decoration);
            return string.Format(OutputMessages.SuccessfullyAdded, decoration.GetType().Name);
        }

        public string AddFish(string aquariumName, string fishType, string fishName, string fishSpecies, decimal price)
        {
            var currentAquarium = aquariums.FirstOrDefault(n => n.Name == aquariumName);
            if(fishType!=nameof(FreshwaterFish) && fishType != nameof(SaltwaterFish))
            {
                throw new InvalidOperationException(ExceptionMessages.InvalidFishType);
            }
            Fish currentFish = default;
            if (fishType == nameof(FreshwaterFish))
            {
                currentFish = new FreshwaterFish(fishName,fishSpecies,price);
            }
            else
            {
                currentFish = new SaltwaterFish(fishName, fishSpecies, price);
            }
            if ((currentFish.GetType().Name == nameof(FreshwaterFish) && currentAquarium.GetType().Name==nameof(FreshwaterAquarium))
                || (currentFish.GetType().Name == nameof(SaltwaterFish) && currentAquarium.GetType().Name == nameof(SaltwaterAquarium)))
            {
                currentAquarium.AddFish(currentFish);
                return string.Format(OutputMessages.EntityAddedToAquarium, currentFish.GetType().Name, aquariumName);
            }
           
           
                return string.Format(OutputMessages.UnsuitableWater);
            
        }

        public string CalculateValue(string aquariumName)
        {
            var currentAquarium = aquariums.Where(n => n.Name == aquariumName).FirstOrDefault();
            decimal decorationSum = default;
            foreach (var decoration in currentAquarium.Decorations)
            {
                decorationSum += decoration.Price;
            }
            foreach (var fish in currentAquarium.Fish)
            {
                decorationSum += fish.Price;
            }
            return string.Format(OutputMessages.AquariumValue, aquariumName, decorationSum);

        }
        public string FeedFish(string aquariumName)
        {
            var curentAquarium = aquariums.FirstOrDefault(n => n.Name == aquariumName);
            foreach (var fish in curentAquarium.Fish)
            {
                fish.Eat();
            }
            return string.Format(OutputMessages.FishFed, curentAquarium.Fish.Count()) ;
        }

        public string InsertDecoration(string aquariumName, string decorationType)
        {
            var currentAquarium = aquariums.Where(n => n.Name == aquariumName).FirstOrDefault();
            var currentDecoration = decorations.FindByType(decorationType);
            if (currentDecoration == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.InexistentDecoration,"asdasdadadasdasdasd"));
            }
            currentAquarium.AddDecoration(currentDecoration);
            decorations.Remove(currentDecoration);
            return string.Format(OutputMessages.EntityAddedToAquarium, currentDecoration.GetType().Name, aquariumName);

        }

        public string Report()
        {
            var sb = new StringBuilder();
            foreach (var aquarium in aquariums)
            {
                sb.AppendLine($"{ aquarium.Name} ({ aquarium.GetType().Name}):");
                string text = "Fish: ";
                int fishCount = aquarium.Fish.Count();
                int curCount = 0;
                if (aquarium.Fish.Count > 0)
                {
                    foreach (var fish in aquarium.Fish)
                    {
                        
                        
                        if (curCount == fishCount - 1)
                        {
                            break;
                        } curCount++; 
                       text += fish.Name + ", ";

                       
                    }
                    text += aquarium.Fish.Last().Name;
                }
                else
                {
                    text += "none";
                }


                sb.AppendLine(text);
                sb.AppendLine($"Decorations: {aquarium.Decorations.Count()}");
                sb.AppendLine($"Comfort: {aquarium.Comfort}");
            }
            return sb.ToString().TrimEnd();

        }
    }
}
