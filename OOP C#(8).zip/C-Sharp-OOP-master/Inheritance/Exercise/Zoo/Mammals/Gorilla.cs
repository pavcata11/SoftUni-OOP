﻿namespace Zoo.Mammals
{
    public class Gorilla : Mammal
    {
        public Gorilla(string name)
            : base(name)
        {
        }
    }
}