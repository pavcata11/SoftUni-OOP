﻿namespace PlayersAndMonsters.Wizards
{
    public class Wizard : Hero
    {
        public Wizard(string username, int level)
            : base(username, level)
        {
        }
    }
}