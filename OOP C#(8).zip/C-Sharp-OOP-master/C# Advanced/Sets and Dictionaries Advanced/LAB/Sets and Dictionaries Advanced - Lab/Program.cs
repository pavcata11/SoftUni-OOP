﻿using System;

namespace Sets_and_Dictionaries_Advanced___Lab
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
