Tasks from the course C# OOP of Softuni.bg
