﻿namespace P03_JediGalaxy
{
    public class Player
    {
        public int Row { get; set; }

        public int Col { get; set; }
    }
}