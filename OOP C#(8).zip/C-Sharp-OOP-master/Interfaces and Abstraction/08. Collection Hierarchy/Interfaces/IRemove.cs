﻿namespace P09.CollectionHierarchy.Interfaces
{
    public interface IRemove
    {
        string Remove();
    }
}