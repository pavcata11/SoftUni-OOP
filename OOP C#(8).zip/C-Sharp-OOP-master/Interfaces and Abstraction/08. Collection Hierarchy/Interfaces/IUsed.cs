﻿namespace P09.CollectionHierarchy.Interfaces
{
    public interface IUsed
    {
        int Used();
    }
}