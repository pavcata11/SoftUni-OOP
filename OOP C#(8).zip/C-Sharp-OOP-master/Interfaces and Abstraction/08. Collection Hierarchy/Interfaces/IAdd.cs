﻿namespace P09.CollectionHierarchy.Interfaces
{
    public interface IAdd
    {
         int Add(string item);
    }
}