﻿namespace P04.Telephony
{
    public interface ICaller
    {
        string Call(string number);
    }
}