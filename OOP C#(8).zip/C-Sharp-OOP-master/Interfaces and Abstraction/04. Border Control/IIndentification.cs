﻿namespace P05.BorderControl
{
    public interface IIndentification
    {
        string Id { get; }
    }
}