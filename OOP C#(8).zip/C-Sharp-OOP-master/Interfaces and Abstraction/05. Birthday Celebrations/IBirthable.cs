﻿namespace P06.BirthdayCelebrations
{
    interface IBirthable
    {
        string Birthdate { get; }
    }
}