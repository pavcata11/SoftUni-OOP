﻿namespace P06.BirthdayCelebrations
{
    public interface IIndentification
    {
        string Id { get; }
    }
}