using System;
using System.Collections.Generic;
using NUnit.Framework;
[TestFixture]
public class HeroRepositoryTests
{ 
    
    private HeroRepository heroRepository;
    
   
    [SetUp]
    public void SetUp()
    {


    }
    [Test]
    public void Ctor_testValidate()
    {
        HeroRepository repository = new HeroRepository();
        repository.Create(new Hero("we", 23));
        var countElementInCollection = repository.Heroes.Count;
        Assert.That(countElementInCollection, Is.EqualTo(1));
    }
    [Test]
    public void Create_nullCreateExcptionHero()
    {
        HeroRepository repository = new HeroRepository();
        var hero = new Hero("weqw", 23);
        hero = null;
        Assert.Throws<ArgumentNullException>(() => repository.Create(hero));
    }
    [Test]
    public void Create_nameWithTheSameNameException()
    {
        HeroRepository repository = new HeroRepository();
        var hero0 = new Hero("w", 23);
        var hero1 = new Hero("w", 235);
        repository.Create(hero0);
        Assert.Throws<InvalidOperationException>(() => repository.Create(hero1));
    }
    [Test]
    public void Create_AddSucessToData()
    {
        HeroRepository repository = new HeroRepository();
        var hero0 = new Hero("w", 23);
        
        string str = $"Successfully added hero {hero0.Name} with level {hero0.Level}";
        var test = repository.Create(hero0);
        var countElementInCollection = repository.Heroes.Count;
        Assert.That(countElementInCollection, Is.EqualTo(1));
        Assert.That(test, Is.EqualTo(str));
       
    }
    [TestCase(null)]
    [TestCase("")]
    [TestCase(" ")]
    public void Remove_IsNullOrWhiteSpaceException(string name)
    {
        HeroRepository repository = new HeroRepository();
        Assert.Throws<ArgumentNullException>(() => repository.Remove(name));

    }
    [Test]
    public void Remove_FindCorrectName()
    {
        string name = "w";
        HeroRepository repository = new HeroRepository();
        var hero0 = new Hero(name, 23);
        repository.Create(hero0);
        
        Assert.That(repository.Remove(name),Is.True);

    }
    [Test]
    public void Test_GetHeroWithHighestLevel()
    {
       
        HeroRepository repository = new HeroRepository();
        var hero0 = new Hero("w1", 23);
        var hero1 = new Hero("w2", 25);
        var hero2 = new Hero("w3", 27);
        repository.Create(hero0);
        repository.Create(hero1);
        repository.Create(hero2);

        Assert.That(hero2, Is.EqualTo(repository.GetHeroWithHighestLevel()));

    }
    [Test]
    public void Test_GetHeroWithGivenName()
    {

        HeroRepository repository = new HeroRepository();
        var hero0 = new Hero("w1", 23);
        var hero1 = new Hero("w2", 25);
        var hero2 = new Hero("w3", 27);
        repository.Create(hero0);
        repository.Create(hero1);
        repository.Create(hero2);

        Assert.That(hero2, Is.EqualTo(repository.GetHero("w3")));

    }



}