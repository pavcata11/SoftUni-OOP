using NUnit.Framework;
using System;
using TheRace;

namespace TheRace.Tests
{
    public class RaceEntryTests
    {
        private UnitDriver driver;

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Ctor_Initialisation()
        {
            var race = new RaceEntry();
            Assert.That(race.Counter, Is.EqualTo(0));

        }
        [Test]
        public void AddDriver_ExceptionNull()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);   
            Assert.Throws<ArgumentNullException>(() => race.AddDriver(new UnitDriver(null, car))); ;
           // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void AddDriver_ExceptionConteins()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            var driver = new UnitDriver("Pavel", car);
            race.AddDriver(driver);
            Assert.Throws<InvalidOperationException>(() => race.AddDriver(driver)); ;
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void AddDriver_Succes()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            var driver = new UnitDriver("Pavel", car);
            race.AddDriver(driver);
            Assert.That(race.Counter, Is.EqualTo(1));
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void AddDriver_SuccesMessageCheck()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            var driver = new UnitDriver("Pavel", car);
            
            Assert.That(race.AddDriver(driver), Is.EqualTo($"Driver {driver.Name} added in race."));
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void CalculateAverageHorsePower_ExceptionIsMInThanEqueal()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            var driver = new UnitDriver("Pavel", car);
            race.AddDriver(driver);
            Assert.Throws<InvalidOperationException>(()=>race.CalculateAverageHorsePower());
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void DriverIsNull()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            
          
            Assert.Throws<InvalidOperationException>(() => race.AddDriver(driver));
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void CalculateAverageHorsePower_CalculateValidl()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            
            var driver = new UnitDriver("Pavel", car);
            var driver1 = new UnitDriver("Pavel1", car);
            var driver2 = new UnitDriver("Pavel2", car);
            race.AddDriver(driver); 
            race.AddDriver(driver1);
            race.AddDriver(driver2);
            Assert.That(race.CalculateAverageHorsePower(), Is.EqualTo((driver1.Car.HorsePower + driver2.Car.HorsePower
                + driver.Car.HorsePower) / 3));
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }
        [Test]
        public void UnitCar()
        {
            var race = new RaceEntry();
            var car = new UnitCar("Audi", 200, 2500.49);
            Assert.That(car.HorsePower, Is.EqualTo(200));
            Assert.That(car.CubicCentimeters, Is.EqualTo(2500.49));
            Assert.That(car.Model, Is.EqualTo("Audi"));
            // Assert.Throws<InvalidOperationException>(() => race.AddDriver(new UnitDriver(null, car))); ;

        }

    }
}