using NUnit.Framework;
using System;

namespace BankSafe.Tests
{
    public class BankVaultTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ctor_Initialisation()
        {
            var bank = new BankVault();
            Assert.That(bank.VaultCells.Count, Is.EqualTo(12));
        }
        [Test]
        public void ctor_InitialisationKeys()
        {
            var bank = new BankVault();
            Assert.That(bank.VaultCells.ContainsKey("A1"), Is.True);
        }
        [Test]
        public void AddItemException_InvalidCels()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            Assert.Throws<ArgumentException>(() => bank.AddItem("invalid", item));
        }
        [Test]
        public void AddItemException_WhenCellsConteinsInvalues()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            bank.AddItem("A1", item);
           
            Assert.Throws<ArgumentException>(() => bank.AddItem("A1", item));
        }
        [Test]
        public void AddItemException_WhenCellsConteinsInvaluesIs()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            bank.AddItem("A1", item);
        
            Assert.Throws<InvalidOperationException>(() => bank.AddItem("B1", item));
        }
        [Test]
        public void CorectCels()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            bank.AddItem("A1", item);

            Assert.That(bank.VaultCells["A1"], Is.EqualTo(item));
        }
        [Test]
        public void CorectMessages()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            Assert.That(bank.AddItem("A1", item),Is.EqualTo($"Item:{item.ItemId} saved successfully!"));
        }
        [Test]
        public void Remove_ExceptionNoCelss()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            Assert.Throws<ArgumentException>(() => bank.RemoveItem("invalid", item));
        }
        [Test]
        public void RemoveValuesDe_ifderentByNull()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
          

            Assert.Throws<ArgumentException>(() => bank.RemoveItem("B1", item));
        }
        [Test]
        public void RemoveValuesAndSetNull()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            bank.AddItem("A1", item);
            bank.RemoveItem("A1", item);
            Assert.That(bank.VaultCells["A1"], Is.EqualTo(null));
        }
        [Test]
        public void RemoveMessageCorrecttly()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            bank.AddItem("A1", item);
        
            Assert.That(bank.RemoveItem("A1", item), Is.EqualTo($"Remove item:{item.ItemId} successfully!"));
        }
        [Test]
        public void OwnerISOwner()
        {
            var bank = new BankVault();
            var item = new Item("owner", "id");
            Assert.That(item.Owner, Is.EqualTo("owner"));
        }




    }
}