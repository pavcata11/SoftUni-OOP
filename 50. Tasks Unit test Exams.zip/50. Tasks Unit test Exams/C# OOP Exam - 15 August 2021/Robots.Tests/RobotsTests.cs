﻿namespace Robots.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class RobotsTests
    {
        [SetUp]
        public void SetUp()
        {

        }
        [Test]
        public void Ctor_initialisation()
        {
            RobotManager rb = new RobotManager(5);
            Assert.AreEqual(5, rb.Capacity);
        }
        [Test]
        public void Ctor_initialisationList()
        {
            RobotManager rb = new RobotManager(5);
            Assert.AreEqual(0, rb.Count);
        }
        [Test]
        public void CapacityLessThanZero()
        {

            Assert.Throws<ArgumentException>(() => new RobotManager(-5));
        }
        [Test]
        public void AddRobotException()
        {
            var robot = new Robot("name",60);
            var rb = new RobotManager(4);
            rb.Add(robot);
            Assert.Throws<InvalidOperationException>(() => rb.Add(robot));
        }
        [Test]
        public void NotEnauhCapacity()
        {
            var robot = new Robot("name", 60);
            var rb = new RobotManager(0);
           
            Assert.Throws<InvalidOperationException>(() => rb.Add(robot));
        }
        [Test]
        public void AddInCollection()
        {
            var robot = new Robot("name", 60);
            var rb = new RobotManager(10);
            rb.Add(robot);
            Assert.AreEqual(1,rb.Count);
        }
        [Test]
        public void RemoveException()
        {
            
            var rb = new RobotManager(10);

            Assert.Throws<InvalidOperationException>(() => rb.Remove("name"));
        }
        [Test]
        public void RemoveSuccess()
        {
            var robot = new Robot("name", 60);
            var rb = new RobotManager(10);
            rb.Add(robot);
            rb.Remove("name");
            Assert.AreEqual(0, rb.Count);
        }
        [Test]
        public void WorkException()
        {
           
            var rb = new RobotManager(10);
           
           
            Assert.Throws<InvalidOperationException>(() => rb.Work("ds,","dsd",67));
        }
        [Test]
        public void WorkExceptionLolBatery()
        {

            var robot = new Robot("name1", 60);
          
            var rb = new RobotManager(10);
            rb.Add(robot);
          

            Assert.Throws<InvalidOperationException>(() => rb.Work("name1", "job", 100));
        }
        [Test]
        public void lessBatery()
        {

            var robot = new Robot("name1", 80);

            var rb = new RobotManager(10);
            rb.Add(robot);
            rb.Work("name1", "job", 10);
            Assert.AreEqual(70, robot.Battery);

        }
        [Test]
        public void ChargeException()
        {

            

            var rb = new RobotManager(10);

            Assert.Throws<InvalidOperationException>(() => rb.Charge("name"));

        }
        [Test]
        public void ChargeESuceess()
        {

            var robot = new Robot("name1", 80);

            var rb = new RobotManager(10);
            rb.Add(robot);
            rb.Work("name1", "job", 10);
            rb.Charge("name1");
            Assert.AreEqual(80, robot.Battery);

        }
    }
}
