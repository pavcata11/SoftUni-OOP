﻿namespace Presents.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class PresentsTests
    {
        [SetUp]
        public void SetUp()
        {

        }
        [Test]
        public void ctor_Initialization()
        {
            Bag bag = new Bag();
            bag.Create(new Present("asd", 45.5));
            var count = bag.GetPresents().Count;
            Assert.That(count, Is.EqualTo(1));    
        }
        [Test]
        public void Create_PresentWithNullException()
        {
            Bag bag = new Bag();
            var present = new Present("dsa", 45.5);
            present = null;

            Assert.Throws<ArgumentNullException>(() => bag.Create(present));
        }
        [Test]
        public void Create_PresentExiistException()
        {
            Bag bag = new Bag();
            var present = new Present("dsa", 45.5);
            bag.Create(present);
            Assert.Throws<InvalidOperationException>(() => bag.Create(present));
        }
        [Test]
        public void Create_ValidPresent ()
        {
            Bag bag = new Bag();
            var present = new Present("w", 23);

            string str = $"Successfully added present {present.Name}.";
            var test = bag.Create(present);
            var countElementInCollection = bag.GetPresents().Count;
            Assert.That(countElementInCollection, Is.EqualTo(1));
            Assert.That(test, Is.EqualTo(str));
        }
        [Test]
        public void Remove_CountTest()
        {
            Bag bag = new Bag();
            var present = new Present("w", 23);
            bag.Create(present);
            Assert.That(bag.Remove(present), Is.True);
            
        }
        [Test]
        public void GetPresentWithLeastMagic_TestforValidatation()
        {
            Bag bag = new Bag();
            var present = new Present("w", 23);
            var present1 = new Present("w1" ,25);
            bag.Create(present);
            bag.Create(present1);
            Assert.That(bag.GetPresentWithLeastMagic(), Is.EqualTo(present));


        }
        [Test]
        public void GetPresent_ByName()
        {
            Bag bag = new Bag();
            var present = new Present("w", 23);
            var present1 = new Present("w1", 25);
            bag.Create(present);
            bag.Create(present1);
            Assert.That(bag.GetPresent("w"), Is.EqualTo(present));


        }


    }
}
