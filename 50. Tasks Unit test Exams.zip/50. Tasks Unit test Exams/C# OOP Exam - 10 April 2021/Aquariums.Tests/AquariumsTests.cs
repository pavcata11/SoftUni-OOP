﻿namespace Aquariums.Tests
{
    using NUnit.Framework;
    using System;
    [TestFixture]
    public class AquariumsTests
    {
        [SetUp]
        public void SetUp()
        {

        }
        [Test]
        public void Ctor_Initialisation()
        {
            Aquarium aquarium = new Aquarium("name",4);
            Assert.That(aquarium.Name, Is.EqualTo("name"));
            Assert.That(aquarium.Capacity, Is.EqualTo(4));
            Assert.That(aquarium.Count, Is.EqualTo(0));

        }
        [Test]
        public void Name_IValidName()
        {
            Aquarium aquarium = new Aquarium("name", 4);
            Assert.That(aquarium.Name, Is.EqualTo("name"));
        }
       
        [TestCase("")]
        [TestCase(null)]
        public void Name_ImvalidNameException(string name)
        {
            Assert.Throws<ArgumentNullException>(() => new Aquarium(name, 10));
        }

        [Test]
        public void Capacity_IsValidCapacity()
        {
            Aquarium aquarium = new Aquarium("name", 4);
            Assert.That(aquarium.Capacity, Is.EqualTo(4));
        }
        [Test]
        public void Capacity_IsInvalidCapacityException()
        {
            Assert.Throws<ArgumentException>(() => new Aquarium("abc", -10));
        }
        [Test]
        public void Count_Validation()
        {
            Aquarium aquarium = new Aquarium("name", 4);
            aquarium.Add(new Fish("name"));
            Assert.That(aquarium.Count, Is.EqualTo(1));
        }
        [Test]
        public void Add_NoCapacityForMoreFish()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            aquarium.Add(new Fish("name"));
            aquarium.Add(new Fish("name1"));
            Assert.Throws<InvalidOperationException>(() => aquarium.Add(new Fish("sda")));
        }
        [Test]
        public void Add_ValidAddingInAquarium()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            aquarium.Add(new Fish("name"));
            aquarium.Add(new Fish("name1"));
            Assert.That(aquarium.Count, Is.EqualTo(2));
        }
        [Test]
        public void RemoveFish_ValidOperation()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            aquarium.Add(new Fish("name"));
            aquarium.RemoveFish("name");
            Assert.That(aquarium.Count, Is.EqualTo(0));
        }
        [Test]
        public void RemoveFish_ExseptionNoFindFishWithThatName()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            aquarium.Add(new Fish("name"));
            Assert.Throws<InvalidOperationException>(() => aquarium.RemoveFish("fakename"));
        }
        [Test]
        public void SelfFish_ExceptionNoFindFishWithThatName()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            aquarium.Add(new Fish("name"));
            Assert.Throws<InvalidOperationException>(() => aquarium.SellFish("fakename"));
        }
        [Test]
        public void SelfFish_ValidFish()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            Fish fish = new Fish("name");
            aquarium.Add(fish);
            //TODO: for this is true
            Assert.That(aquarium.SellFish("name").Available, Is.False);
            Assert.That(aquarium.SellFish("name"),Is.EqualTo(fish));
        }
        [Test]
        public void Report_CheckForWriteCorection()
        {
            Aquarium aquarium = new Aquarium("name", 2);
            Fish fish = new Fish("name");
            aquarium.Add(fish);
            string str = $"Fish available at {aquarium.Name}: {fish.Name}";
            Assert.That(str, Is.EqualTo(aquarium.Report()));
        }



    }
}
