// Use this file for your unit tests.
// When you are ready to submit, REMOVE all using statements to Festival Manager (entities/controllers/etc)
// Test ONLY the Stage class.
using FestivalManager.Entities;
using NUnit.Framework;
using System; 
namespace FestivalManager.Tests
{
    

    [TestFixture]
	public class StageTests
    {
		[Test]
	    public void Ctor_Initialisation() //TODO Check just one prop in ctor to initialisation Corectly
	    {
			Stage stage = new Stage();
			TimeSpan time = new TimeSpan();
			stage.AddPerformer(new Performer("firstName", "lastName", 23));
			Assert.That(stage.Performers.Count, Is.EqualTo(1));
		}
		[Test]
		public void AddPerformer_ExceptionAgeSmallThanNeeded()
		{
			Stage stage = new Stage();
			Assert.Throws<ArgumentException>(() => stage.AddPerformer(new Performer("firstName", "lastName", 3)));
		}
		[Test]
		public void AddPerformer_ValidPerformers()
		{
			Stage stage = new Stage();
			stage.AddPerformer(new Performer("firstName", "lastName", 23));
			Assert.That(stage.Performers.Count, Is.EqualTo(1));
		}
		[Test]
		public void AddSong_ExceptionDurationTimeisLessThanNeeded()
		{
			Stage stage = new Stage();
			TimeSpan span = new TimeSpan(0, 0, 0, 23, 0);
			Song song = new Song("name", span);
			Assert.Throws<ArgumentException>(() => stage.AddSong(song));
		}
        /*[Test]
        public void AddSong_ValidSong()//TODO  way to test add song to colectionSongs
        {
            Stage stage = new Stage();
            TimeSpan span = new TimeSpan(0, 0, 1, 23, 0);
            Song song = new Song("name", span);
            stage.AddSong(song);

        }*/
        [Test]
        public void AddSongToPerformer_ValidSong()//TODO  way to test add song to colectionSongs
        {
            Stage stage = new Stage();
            TimeSpan span = new TimeSpan(0, 0, 1, 23, 0);
            Song song = new Song("name", span);
			Performer performer = new Performer("firstName", "lastName", 23);
			stage.AddPerformer(performer);
			stage.AddSong(song);
			stage.AddSongToPerformer("name", "firstName lastName");
			

			 Assert.That(performer.SongList.Count, Is.EqualTo(1));
			//TDOD: string test

		}
		[Test]
		public void AddSongToPerformer_Exception()
		{
			Stage stage = new Stage();
			
			Performer performer = new Performer("firstName", "lastName", 23);
			stage.AddPerformer(performer);

			Assert.Throws<ArgumentException>(() => stage.AddSongToPerformer("fdsf","fds"));
		}
		[Test]
		public void AddSongToPerformer_ExceptionNllvalidate()
		{
			Stage stage = new Stage();
			Assert.Throws<ArgumentNullException>(() => stage.AddSongToPerformer(null, null));
			Assert.Throws<ArgumentNullException>(() => stage.AddSongToPerformer(null, "fsdf"));
			Assert.Throws<ArgumentNullException>(() => stage.AddSongToPerformer("fdsf", null));
		}
		[Test]
		public void AddSongToPerformer_ExceptionSongIncorectName()
		{
			Stage stage = new Stage();
			Performer performer = new Performer("firstName", "lastName", 23);
			stage.AddPerformer(performer);

			TimeSpan span = new TimeSpan(0, 0, 2, 0, 0);
			Song song = new Song("name", span);
			stage.AddSong(song);

			Assert.Throws<ArgumentException>(() => stage.AddSongToPerformer("nosongname", "firstName lastName"));
		}
		[Test]
		public void Play_Valid()
		{
			Stage stage = new Stage();
			TimeSpan span = new TimeSpan(0, 0, 2, 0, 0);
			Song song = new Song("name", span);
			Performer performer = new Performer("firstName", "lastName", 23);
			stage.AddPerformer(performer);
			stage.AddSong(song);
			stage.AddSongToPerformer("name", "firstName lastName");
			string str = $"{stage.Performers.Count} performers played {1} songs";
			Assert.That(stage.Play, Is.EqualTo(str));

		}
		





	}
}