// Use this file for your unit tests.
// When you are ready to submit, REMOVE all using statements to Festival Manager (entities/controllers/etc)
// Test ONLY the Stage class. 
namespace FestivalManager.Tests
{
    using FestivalManager.Entities;
    using NUnit.Framework;
    using System;

    [TestFixture]
	public class StageTests
    {
		private Performer performer;
		private Song song;
		[Test]
	    public void Ctor_Songs()
	    {
			TimeSpan span = new TimeSpan(5,4,23);
			var songs = new Song("Name",span);
			Assert.That(songs.Name, Is.EqualTo("Name"));
			Assert.That(songs.Duration, Is.EqualTo(span));
			Assert.That(songs.ToString, Is.EqualTo("Name (04:23)"));
		}
		[Test]
		public void Ctor_Performance()
		{
			var per = new Performer("firstName", "LastName", 40);
			Assert.That(per.FullName, Is.EqualTo("firstName LastName"));
			Assert.That(per.Age, Is.EqualTo(40));
			Assert.That(per.ToString, Is.EqualTo("firstName LastName"));
			Assert.That(per.SongList, Is.Empty) ;
			Assert.That(per.SongList.Count, Is.EqualTo(0));
		}
		[Test]
		public void Ctor_Stage()
		{
			var stage = new Stage();
			Assert.That(stage.Performers, Is.Empty);
			Assert.That(stage.Performers.Count, Is.EqualTo(0));
		}
		[Test]
		public void AddPerformerValidMethod()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentNullException>(() => stage.AddPerformer(performer));
		}
		[Test]
		public void AddPerformerExceptionLessThan18()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentException>(() => stage.AddPerformer(new Performer("a", "b", 10)));
		}
		[Test]
		public void AddPerformerInColection()
		{
			var stage = new Stage();
			stage.AddPerformer(new Performer("a", "b", 20));
			Assert.That(stage.Performers.Count, Is.EqualTo(1));
		}
		[Test]
		public void AddSongException()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentException>(() => stage.AddSong(new Song("a", new TimeSpan(0, 0, 23))));
		}
		[Test]
		public void AddSongValidNullValue()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentNullException>(() => stage.AddSong(song));
		}
		[Test]
		public void AddSongToPerformValidNullValue()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentNullException>(() => stage.AddSongToPerformer(null,"performer"));
			Assert.Throws<ArgumentNullException>(() => stage.AddSongToPerformer("name", null));
		}
		[Test]
		public void AddSongToPerformGetPerformerExeption()
		{
			var stage = new Stage();
			Assert.Throws<ArgumentException>(() => stage.AddSongToPerformer("name", "performer"));
			
		}
		
		[Test]
		public void AddSongToPerformGeSongExeption()
		{
			var stage = new Stage();
			stage.AddPerformer(new Performer("a", "b", 20));
			Assert.Throws<ArgumentException>(() => stage.AddSongToPerformer("name", "a b"));

		}
		[Test]
		public void AddSongToPerformToSongList()
		{
			var stage = new Stage();
			var per = new Performer("a", "b", 20);
			var song = new Song("a", new TimeSpan(0, 3, 23));
			stage.AddPerformer(per);
			stage.AddSong(song);
			per.SongList.Add(song);
			Assert.That(per.SongList.Count, Is.EqualTo(1));

		}
		[Test]
		public void MessageCorectky()
		{
			var stage = new Stage();
			var per = new Performer("a", "b", 20);
			var song = new Song("a", new TimeSpan(0, 3, 23));
			stage.AddPerformer(per);
			stage.AddSong(song);
			
			Assert.That(stage.AddSongToPerformer("a","a b"), Is.EqualTo($"{song} will be performed by {per}"));

		}
	}
}