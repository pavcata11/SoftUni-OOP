﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
	public class WarController
	{
		private IList<Character> party;
		private Stack<Item> pool;
		public WarController()
		{
			party = new List<Character>();
			pool = new Stack<Item>();
		}

		public string JoinParty(string[] args)
		{
			string characterType = args[0];
			string name = args[1];
            switch (characterType)
            {
				case "Priest":
					Priest priest = new Priest(name);
					party.Add(priest);
					break;
				case "Warrior":
					Warrior warrior = new Warrior(name);
					party.Add(warrior);
					break;
				default:
					throw new ArgumentException(string.Format(ExceptionMessages.InvalidCharacterType, name));
					
            }
			return string.Format(SuccessMessages.JoinParty, name);

		}

		public string AddItemToPool(string[] args)
		{
			string itemName = args[0];
			switch(itemName)

			{
				case "FirePotion":
			    FirePotion firePotion = new FirePotion();
				pool.Push(firePotion);
				break;
				case "HealthPotion":
				HealthPotion healthPotion = new HealthPotion();
				pool.Push(healthPotion);
				break;
				default:
					throw new ArgumentException(string.Format(ExceptionMessages.InvalidItem, itemName));

			}
			return string.Format(SuccessMessages.AddItemToPool, itemName);
		}

		public string PickUpItem(string[] args)
		{
			string characterName = args[0];
			var x = party.FirstOrDefault(n => n.Name == characterName);
            if (x == null)
            {
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, characterName);
            }
            if (pool.Count == 0)
            {
				throw new InvalidOperationException(ExceptionMessages.ItemPoolEmpty);

			}
			Item item = pool.Pop();
			x.Bag.AddItem(item);
			return string.Format(SuccessMessages.PickUpItem, characterName, item.GetType().Name);
		}

		public string UseItem(string[] args)
		{
			string characterName = args[0];
			string itemName = args[1];
			var character = party.Where(c => c.Name == characterName).FirstOrDefault();
            if (character == null)
            {
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, characterName);
            }
			var item = character.Bag.GetItem(itemName);
			character.UseItem(item);
			return string.Format(SuccessMessages.UsedItem, character.Name, itemName);

		}

		public string GetStats()
		{
			/*Returns info about all characters, sorted by whether they are alive(descending), then by their health(descending)
The format of a single character is:
"{name} - HP: {health}/{baseHealth}, AP: {armor}/{baseArmor}, Status: {Alive/Dead}"
Returns the formatted character info for each character, separated by new lines.*/
			var sb = new StringBuilder();
			var characters = party.OrderByDescending(alive => alive.IsAlive == true).ThenByDescending(x => x.Health);
            foreach (var item in characters)
            {
				sb.AppendLine(string.Format(SuccessMessages.CharacterStats, item.Name, item.Health, item.BaseHealth, item.Armor, item.BaseArmor, item.IsAlive ? "Alive" : "Dead"));
            }
			return sb.ToString().TrimEnd();

		}

		public string Attack(string[] args)
		{
			string attackerName = args[0];
			string receiverName = args[1];
			var atacker = party.FirstOrDefault(n => n.Name == attackerName);
            if (atacker == null)
            {
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, attackerName);
            }
			var reciever = party.FirstOrDefault(n => n.Name == receiverName);
			if (reciever == null)
			{
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, receiverName);
			}
			Warrior warrior = atacker as Warrior;
            if (warrior == null)
            {
				throw new ArgumentException(ExceptionMessages.AttackFail, attackerName);
			}
			warrior.Attack(reciever);
            string output = string.Format(SuccessMessages.AttackCharacter, attackerName, receiverName, atacker.AbilityPoints, reciever.Name, reciever.Health, reciever.BaseHealth, reciever.Armor, reciever.BaseArmor);
            if (reciever.Health <= 0)
            {
				string temp = string.Format(SuccessMessages.AttackKillsCharacter, reciever.Name);
				output = $"{output}\n{temp}";
            }
			return output;

		}

		public string Heal(string[] args)
		{
			string healerName = args[0];
			string healingReceiverName = args[1];
			var healer = party.FirstOrDefault(n => n.Name == healerName);
			if (healer == null)
			{
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, healerName);
			}
			var reciever = party.FirstOrDefault(n => n.Name == healingReceiverName);
			if (reciever == null)
			{
				throw new ArgumentException(ExceptionMessages.CharacterNotInParty, healingReceiverName);
			}

			Priest priest = healer as Priest;
			if (priest == null)
			{
				throw new ArgumentException(ExceptionMessages.HealerCannotHeal, healerName);
			}
			priest.Heal(reciever);

			return string.Format(SuccessMessages.HealCharacter, healer.Name, reciever.Name,
				healer.AbilityPoints, reciever.Name, reciever.Health);
		}
	}
}
