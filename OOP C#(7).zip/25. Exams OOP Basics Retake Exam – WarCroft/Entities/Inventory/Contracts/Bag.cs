﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Inventory.Contracts
{
    public abstract class Bag : IBag
    {
        //Capacity – an integer number. Default value: 100
        //   Load – Calculated property.The sum of the weights of the items in the bag.
        //Items – Read-only collection of type Item
        private IList<Item> colection;
        public int Capacity { get; set; } 

        public int Load => Items.Sum(i => i.Weight);

        public IReadOnlyCollection<Item> Items { get; }

        public Bag(int capacity)
        {
            Capacity = capacity;
            colection = new List<Item>();
            Items = new ReadOnlyCollection<Item>(colection);
        }
        public void AddItem(Item item)
        {
            //If the current load + the weight of the item attempted to be added is greater than the bag’s capacity, throw an InvalidOperationException with the message "Bag is full!"
            //  If the check passes, the item is added to the bag.
            if (this.Load + item.Weight >= Capacity)
            {
                throw new InvalidOperationException(ExceptionMessages.ExceedMaximumBagCapacity);
            }
            colection.Add(item);

        }

        public Item GetItem(string name)
        {
            //If no items exist in the bag, throw an InvalidOperationException with the message "Bag is empty!"
            // If an item with that name doesn’t exist in the bag, throw an ArgumentException with the message "No item with name {name} in bag!"
            //If both checks pass, the item is removed from the bag and returned to the caller.
            if (colection.Count == 0)
            {
                throw new InvalidOperationException(ExceptionMessages.EmptyBag);
            }
            var x = colection.Where(n => n.GetType().Name == name).FirstOrDefault();
            if (x == null)
            {
                throw new ArgumentException(string.Format(ExceptionMessages.ItemNotFoundInBag,name));
            }
            colection.Remove(x);
            return x;

        }
    }
}
