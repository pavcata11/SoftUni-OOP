﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory.Contracts;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
        // TODO: Implement the rest of the class.
        //•	Name – a string (cannot be null or whitespace).
        /*o Throw an ArgumentException with the message "Name cannot be null or whitespace!"
•	BaseHealth – a floating-point number – the starting and also the maximum health a character can have
•	Health – a floating-point number(current health).
o Health(current health) should never be more than the BaseHealth or less than 0. 
•	BaseArmor – a floating-point number – the starting armor a character has
•	Armor – a floating-point number(current armor)
o Armor – the current amount of armor left – can not be less than 0.
•	AbilityPoints – a floating-point number
•	Bag – a parameter of type Bag

•	IsAlive – boolean value(default value: True)
		*/
        private string name;

        public string Name
        {
            get 
            {
                return name;
            }
            set 
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.CharacterNameInvalid);
                }
                name = value;
            }
        }
        public double BaseHealth { get; set; }
        private double health;

        public double Health
        {
            get 
            {
                return health;
            }
            set 
            {
                if(value<BaseHealth || value > 0)
                {
                    health = value;
                }
              
            }
        }
        public double BaseArmor { get; set; }
        private double armor;

        public double Armor
        {
            get 
            { 
                return  armor;
            }
            set 
            {
                if (value > 0)
                {
                    armor = value;
                }
               
               
            }
        }
        public double AbilityPoints  { get; set; }
        public Bag Bag { get; set; }

        public bool IsAlive { get; set; } = true;

		protected void EnsureAlive()
		{
			if (!this.IsAlive)
			{
				throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
			}
		}
        public void TakeDamage(double hitPoints)
        {
            EnsureAlive();
            var characterTakesDamage = hitPoints;
            this.Armor -= hitPoints;
            if (this.Armor < 0)
            {
                this.Health -= this.Armor;
            }
            if (this.Health <= 0)
            {
                IsAlive = false;
            }
        }
        public void UseItem(Item item)
        {
            EnsureAlive();
            item.AffectCharacter(this);
        }
        public Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            Name = name;
            Health = health;
            Armor = armor;
            AbilityPoints = abilityPoints;
            Bag = bag;
        }
    }
}