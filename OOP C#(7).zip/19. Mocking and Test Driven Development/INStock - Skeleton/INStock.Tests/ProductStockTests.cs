﻿namespace INStock.Tests
{
    using NUnit.Framework;
    using System.Linq;

    public class ProductStockTests
    {
        private static  Enumerable<Product> Generator()
        {

        }
    }
}
