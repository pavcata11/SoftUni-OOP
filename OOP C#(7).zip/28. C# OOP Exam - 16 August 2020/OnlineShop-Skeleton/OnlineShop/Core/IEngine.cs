﻿namespace OnlineShop.Core
{
    public interface IEngine
    {
        void Run();
    }
}