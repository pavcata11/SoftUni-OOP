﻿using SpaceStation.Models.Bags.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Models.Bags
{
    public class Backpack : IBag
    {
        private IList<string> items;
        public ICollection<string> Items { get; }

        public Backpack()
        {
            items = new List<string>();
            Items = new List<string>(items);
        }

    }
}
