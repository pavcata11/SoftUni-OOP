﻿using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Bags.Contracts;
using SpaceStation.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Models.Astronauts
{
    public abstract class Astronaut:IAstronaut
    {
        /* •	Name – string
 o   If the name is null or whitespace, throw an ArgumentNullException with message: "Astronaut name cannot be null or empty."
 o All names are unique
 •	Oxygen –  double
 o   The oxygen of аn astronaut
 o   If the oxygen is below 0, throw an ArgumentException with message:
  "Cannot create Astronaut with negative oxygen!"
 •	CanBreath – calculated property, which returns bool
 •	Bag – IBag
 o   A property of type Backpack*/
        private string name;

        public string Name
        {
            get
            { 
                return name;
            }
            set 
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.InvalidAstronautName);
                }
                name = value;
            }
        }
        private double oxygen ;

        public double Oxygen 
        {
            get
            {
                return  oxygen ; 
            }
            set 
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidOxygen);
                }
                oxygen  = value;
            }
        }
        public bool CanBreath { get; set; }
        public IBag Bag { get; }
       
        public virtual void Breath()
        {
            Oxygen -= 10;
           

            
        }
        public Astronaut(string name, double oxygen)
        {
            Name = name;
            Oxygen = oxygen;
        }

    }
}
