﻿using SpaceStation.Models.Planets.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Models.Bags
{
    /*    •	Name – string
    o   If the name is null or whitespace, throw an ArgumentNullException with message: "Invalid name!"
    •	Items – a collection of strings*/

    public class Planet : IPlanet
    {
        private IList<string> items;
        public ICollection<string> Items { get; }

        public Planet()
        {
            items = new List<string>();
            Items = new List<string>(items);
        }
        public string Name {get;}
    }
}
