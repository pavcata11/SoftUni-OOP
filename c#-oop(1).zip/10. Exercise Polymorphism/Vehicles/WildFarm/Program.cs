﻿using System;
using System.Collections.Generic;

namespace WildFarm
{
   public  class Program
    {
        static void Main(string[] args)
        {
            var comand = Console.ReadLine();
            int counter = 0;
            var animal = new List<Animal>();
            while (comand!="End")
            {
                var tokens = comand.Split();
                if (counter % 2 == 0)
                {
                    switch (tokens[0])
                    {
                       

                        case "Cat":
                            Cat cat = new Cat(tokens[1], double.Parse(tokens[2]), tokens[3], tokens[4]);
                            animal.Add(cat);
                            break;
                        case "Tiger":
                            Tiger tiger = new Tiger(tokens[1], double.Parse(tokens[2]), tokens[3] ,tokens[4]);
                            animal.Add(tiger);
                            break;
                        case "Owl":
                            Owl owl = new Owl(tokens[1], double.Parse(tokens[2]), double.Parse(tokens[3]));
                            animal.Add(owl);
                            break;
                        case "Hen":
                            Hen hen = new Hen(tokens[1], double.Parse(tokens[2]),double.Parse(tokens[3]));
                            animal.Add(hen);
                            break;

                        case "Mouse":
                            Mouse mouse = new Mouse(tokens[1], double.Parse(tokens[2]),tokens[3]);
                            animal.Add(mouse);
                            break;
                       
                        case "Dog":
                            Dog dog = new Dog(tokens[1], double.Parse(tokens[2]), tokens[3]);
                            animal.Add(dog);
                            break;
                        default:
                            break;
                    }
                   
                    // animals
                }
                else
                {
                    var curentAnimal = animal[animal.Count - 1];
                    Console.WriteLine(curentAnimal.producingSound());
                    if (curentAnimal is Hen hen)
                    {
                        hen.Weight += int.Parse(tokens[1]) * 0.35;
                        hen.FoodEaten += int.Parse(tokens[1]);
                    }
                    else if (curentAnimal is Mouse mouse && (tokens[0] == "Vegetable" || tokens[0] == "Fruit"))
                    {
                        mouse.Weight += int.Parse(tokens[1]) * 0.10;
                        mouse.FoodEaten += int.Parse(tokens[1]);
                    }
                    //•	Cats eat vegetables and meat;
                    else if (curentAnimal is Cat cat && (tokens[0] == "Vegetable" || tokens[0] == "Meat"))
                    {
                        cat.Weight += int.Parse(tokens[1]) * 0.30;
                        cat.FoodEaten += int.Parse(tokens[1]);
                    }
                    else if (curentAnimal is Tiger tiger && tokens[0] == "Meat")
                    {
                        tiger.Weight += int.Parse(tokens[1]) * 1.00;
                        tiger.FoodEaten += int.Parse(tokens[1]);
                    }
                    else if (curentAnimal is Dog dog && tokens[0] == "Meat")
                    {
                        dog.Weight += int.Parse(tokens[1]) * 0.40;
                        dog.FoodEaten += int.Parse(tokens[1]);
                    }
                    else if (curentAnimal is Owl owl && tokens[0] == "Meat")
                    {
                        owl.Weight += int.Parse(tokens[1]) * 0.25;
                        owl.FoodEaten += int.Parse(tokens[1]);
                    }
                    else
                    {
                        Console.WriteLine($"{curentAnimal.GetType().Name} does not eat {tokens[0]}!");
                    }


                }
                counter++;
                comand = Console.ReadLine();
            }
            foreach (var item in animal)
            {
                Console.WriteLine(item);
            }
        }
    }
}
