﻿namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
