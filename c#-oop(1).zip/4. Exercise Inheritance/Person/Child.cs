﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Child : Person
    {
        public Child(string nmae, int age) 
            : base(nmae, age)
        {

        }
        public override int Age 
        {
            get
            {
                return base.Age;
            }
            set
            {
                if (value > 15)
                {
                    throw new ArgumentException("Age cannot grader than 15");
                }
                base.Age = value;
            }
        }
    }
}
