﻿using System;

namespace ExplicitInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            while (command != "End")
            {
                string[] tookens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                IResident citizen = new Citizen();
                IPerson citizen1 = new Citizen();
                Console.WriteLine(citizen1.Name1);
                citizen.Name = tookens[0];
                Console.Write(citizen.GetName());
                command = Console.ReadLine();
                Console.WriteLine();
            }
        }
    }
}
