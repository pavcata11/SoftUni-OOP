﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExplicitInterfaces
{
    public class Citizen : IResident, IPerson
    {
        public object Name { get; private set; }
        string IResident.Name { get ; set; }
        string IPerson.Name { get ; set; }
        string IResident.Country { get; set; }
        int IPerson.Age { get ; set ; }

        string IResident.GetName()
        {
            return "Mr/Ms/Mrs ";
        }



        string IPerson.GetName(IPerson name) => name.Name.ToString();

        string IPerson.Name1 => Name.ToString();
    }
}
