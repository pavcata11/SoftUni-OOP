﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite
{
    public interface ILieutenantGeneral:IMission
    {
        public  HashSet<Soldier> Soldiers { get; set; }
    }
}
