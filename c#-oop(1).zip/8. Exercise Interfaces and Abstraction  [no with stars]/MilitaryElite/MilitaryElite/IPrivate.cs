﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite
{
    public interface IPrivate:IMission
    {
        public decimal Salary { get; set; }
    }
}
