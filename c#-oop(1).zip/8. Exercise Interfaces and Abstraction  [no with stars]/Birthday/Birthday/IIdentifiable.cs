﻿namespace Birthday
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
