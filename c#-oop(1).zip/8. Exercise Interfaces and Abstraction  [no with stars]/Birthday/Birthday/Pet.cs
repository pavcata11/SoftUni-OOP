﻿namespace Birthday
{
    public class Pet : LivingBeing
    {
        public Pet(string birthDate, string name) : base(birthDate, name)
        {
        }
    }
}
