﻿namespace Birthday
{
    public interface IBirthable
    {
        string Name { get; }

        string BirthDate { get; }
    }
}
