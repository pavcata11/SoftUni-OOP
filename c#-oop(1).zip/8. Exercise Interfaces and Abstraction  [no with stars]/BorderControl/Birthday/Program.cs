﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
   public class Program
    {
        static void Main(string[] args)
        {
            string comand = Console.ReadLine();
            var listOfId = new List<Ruler>();
          
            while (comand != "End")
            {
                var tokens = comand.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0]=="Robot")
                {
                    var robot = new Robots(tokens[1], tokens[2]);
                    listOfId.Add(robot);
                }
                else if(tokens[0] == "Citizen")
                {
                    var citizen = new Citizens(tokens[1], int.Parse(tokens[2]),tokens[3],tokens[4]);
                    listOfId.Add(citizen);
                }
                else if (tokens[0] == "Pet")
                {
                    var pet = new Pet(tokens[1], tokens[2]);
                    listOfId.Add(pet);
                }

                    comand = Console.ReadLine();
            }
            string numebrFind = Console.ReadLine();

            foreach (var item in listOfId)
            {
                
                if (item.GetType().Name == "Citizens")
                {
                  
                    var citizen = item as Citizens;
                    bool isIdOk = citizen.Birthdates.EndsWith(numebrFind);
                    if (isIdOk)
                    {
                        Console.WriteLine(citizen.Birthdates);
                       
                    }
                }
                else if (item.GetType().Name == "Pet")
                {

                    var pet = item as Pet;
                    bool isIdOk = pet.Birthdate.EndsWith(numebrFind);
                    if (isIdOk)
                    {
                        Console.WriteLine(pet.Birthdate);

                    }
                }
            }
            
        }
    }
}
