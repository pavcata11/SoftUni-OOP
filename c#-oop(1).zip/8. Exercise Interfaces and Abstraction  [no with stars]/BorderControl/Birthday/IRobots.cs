﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IRobots
    {
        public string Model { get; set; }
        public string Id { get; set; }


    }
}
