﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Rebel:Ruler,IBuyer
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Group { get; set; }

        public Rebel(string name, int age, string group)
        {
            Name = name;
            Age = age;
            Group = group;
        }

        public void BuyFood()
        {
            throw new NotImplementedException();
        }

        public int Food()
        {
            return 5;
        }
    }
}
