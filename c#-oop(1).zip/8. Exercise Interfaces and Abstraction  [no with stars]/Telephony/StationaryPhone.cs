﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public class StationaryPhone : IStationaryPhone
    {
        public void Call(string item)
        {
            var charsNumber = item.ToCharArray();
            foreach (var chars in charsNumber)
            {
                if (!char.IsDigit(chars))
                {
                    Console.WriteLine("Invalid number!");
                    return;
                }
            }
            Console.WriteLine($"Dialing... {item}");
        }
    }
}
