﻿using System;

namespace Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var inputFirstLine = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var inputSecondLine = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var smartPhone = new Smartphone();
            var stationaryPhone = new StationaryPhone();
            foreach (var item in inputFirstLine)
            {
                if (item.Length == 10)
                {
                    smartPhone.Calling(item);
                }
                else if(item.Length == 7)
                {
                    stationaryPhone.Call(item);
                }
                else
                {
                    Console.WriteLine("Invalid number!");
                }
            }
            foreach (var item in inputSecondLine)
            {

                smartPhone.Browsing(item);
            }
        }
    }
}
