﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public class Smartphone : ISmartPhone
    {
        public void Browsing(string item)
        {
            var charsbrowsering = item.ToCharArray();
            foreach (var chars in charsbrowsering)
            {
                if (char.IsDigit(chars))
                {
                    Console.WriteLine("Invalid URL!");
                    return;
                }
            }
            Console.WriteLine("Browsing: " + item +"!");
        }

        public void Calling(string item)
        {
            var charsNumber = item.ToCharArray();
            foreach (var chars in charsNumber)
            {
                if (!char.IsDigit(chars))
                {
                    Console.WriteLine("Invalid number!");
                    return;
                }
            }
            Console.WriteLine($"Calling... {item}");
        }
    }
}
