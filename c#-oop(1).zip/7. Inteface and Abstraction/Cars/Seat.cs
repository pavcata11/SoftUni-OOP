﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
  public  class Seat:ICar
    {
        private string model;
        private string color;

        public Seat(string model, string color)
        {
            Model= model;
            Color =  color;
        }

        public string Model { get ; set; }
        public string Color { get ; set ; }
        public string Start { get; set; }
        public string Stop { get ; set ; }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{Color} {this.GetType().Name} {Model}");
            sb.AppendLine("Engine start");
            sb.AppendLine("Breaaak!");
            return sb.ToString().TrimEnd();
        }
    }
}
